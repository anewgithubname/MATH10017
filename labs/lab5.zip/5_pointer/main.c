/*
Rename the name of the c file with your_UoB_ID.c
*/
#include <stdio.h>

/*
Returns the index of the samllest element in a double array. 
len: length of the array
array: double array contains non-duplicate elements, ranging from [0,1].
*/
int find_minimum(int len, double array[len]){
    //TODO: Write your code below
}

/*
Find the smallest three values in a double array
len: length of the array
array: double array contains non-duplicate elements, ranging from [0,1].
bottom: stores three smallest values in the double array. 
*/
void find_bottom3(int len, double array[len], double bottom[3]){
    //TODO: Write your code below
}

//TODO: write your swap function below. 

void main(){
    // homework 1
    printf("homework 1--------------\n");
    double vec[] = {0.2, 0.5, .3,.001,.1};
    printf("The index of the smallest is: %d\n",  find_minimum(5, vec));

    // homework 2
    printf("\nhomework 2--------------\n");
    double top3[] = {999,999,999};
    find_bottom3(5, vec, top3);
    printf("Three smallest values are %.5f %.5f %.5f\n", top3[0],top3[1],top3[2]);

    // homework 3
    printf("\nhomework 3--------------\n");
    int a = -9999; int *pa = &a;
    *pa = 1; 
    printf("%d \n", a);

    int a1 = 3, a2 = 2; 

    //TODO: call your function here
    //you cannot swap values of a1, a2 and a3 here. 
    //you must call a function to swap values for you.

    printf("%d %d\n", a1, a2); 
    // displays "2 3 4"
}
