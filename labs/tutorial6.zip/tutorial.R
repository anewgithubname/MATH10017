library(imager)
img <- load.image("UoB.jpg")
img <- grayscale(img)
m <- as.matrix(img)

# writr your code here
