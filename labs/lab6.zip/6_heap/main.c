#include<stdio.h>
#include<stdlib.h>

/*
generate a copy of an array, appending it with an additional element a
array: input, the original array
len: intput, the length of the original array
a: input, the element to be appended. 
return: a int pointer, pointing to the copy array. 
*/
int *append(int *array, int len, int a){
    //TODO: Write your code below. Delete "return NULL;" before you start.  
    return NULL; 
}

/*
generate a sliced copy of an array, including only elements from array[start] to array[end-1].
array: input, the original array
start, end: inputs, the start and end index of the slice. 
return: a int pointer, pointing to the sliced copy. 
*/
int *slice(int *array, int start, int end){
    //TODO: Write your code below. Delete "return NULL;" before you start.  
    return NULL;
}

void main(){
    printf("----------- homework 2 output------------\n");
    //create a test case
    int array[] = {1,2,3,4,5,6,7};
    int len = 7;
    //call your append function
    int *newarray = append(array,len,8);

    if(newarray != NULL){// the program will crash if I do not check, why?
        //print out the appended array.
        for (int i = 0; i < len+1; i++){
            printf("%d ", newarray[i]);
        }
        printf("\n");
        //DO NOT FORGET TO FREE THE MEMORY!
        free(newarray);
    }

    printf("\n----------- homework 3 output ------------\n");
    int start = 1, end = 3; 
    //call your slice function
    newarray = slice(array, start, end);

    if(newarray != NULL){// the program will crash if I do not check, why?
        //print out the sliced array.
        for (int i = 0; i < end-start; i++){
            printf("%d ", newarray[i]);
        }
        printf("\n");
        //DO NOT FORGET TO FREE THE MEMORY!
        free(newarray);
    }
}