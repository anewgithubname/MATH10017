/*
This is only a template for your code. 
You can choose to use this template or not. It is up to you. 
*/

// If you want to use any other headers, please consult the lecturer before hand. 
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include<math.h> 

//If you want to use the matrix structure, define the structure below. 


/*
Write appropriate functions here. 

Some examples are given to you below. You can choose to use them or not. 
Uncomment those fuctions (ctrl+/ on windows) to start coding. 

We strongly discourage you to write everything in the main function. 
*/


/*
Read a matrix from file.
filename: the file that contains the matrix.
*/
// Matrix read_matrix(char *filename){
    //YOUR CODE HERE
// }

/*
 * pairwise_dist
 *
 * Store the distance between row i of Matrix A and
 * row j of Matrix B in i-j entry of Matrix C, for all i,j. 
 */

// void pairwise_dist(Matrix A, Matrix B, Matrix C){
    //YOUR CODE HERE
// }

/*
 * minimum5
 *
 * Store the indices of the 5 smallest elements of array in indices.
 */

// void minimum5(int len, int array[len], int indices[5]){
    //YOUR CODE HERE
// }

//You may want to write some extra functions here

/*
This below function is for helping you visualize images in our dataset. 
It is up to you to use it or not. 

visualize a flattened image, stored in array a. 
height: height of the image
width: width of the image
a: the array contains a flattend image.
For more detail, 
check out: https://github.com/anewgithubname/MATH10017/blob/main/lecs/tutorial.pdf
*/ 
void visualize(int height, int width, int a[])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            if( a[i*width+j] < 85){
                printf(" ");
            }else if(a[i*width+j] >= 85 && a[i*width+j] <= 170){
                printf("I");
            }else{
                printf("M");
            }
        }
        printf("\n");
    }
}

/*
This is the main function of your code. 
Read this 
https://github.com/anewgithubname/MATH10017/blob/main/lecs/lec9.pdf
before you start. 
*/
void main()
{   
    printf("This is the final project of MATH10017.\n");
    printf("Part I: \n");
    //Part I: loading matrices from data.
    //TODO: load matrix X from X.matrix
    //TODO: Print out "N, M". 
    //Do NOT print out anything other than N, M and a comma in between. 

    //TODO: load matrix T from T.matrix and print out "L". 

    //TODO: load matrix Y from Y.matrix
    //TODO: Print out "There are C images that are digit 1." 
    //where C is the number of images in X that are digit 1. 
    //NOTE: Do not print out anything other than the above sentence.

    printf("Part II: \n");
    //Part II: Computing D.
    //HINT: You may want to test your code on some smaller, 
    //"toy" matrices, to make sure they work. 
    //HINT: You can test your Part II code in a different file and copy it here
    // to avoid cluttering. 


    printf("Part III: \n");
    //Part III: Prediction
    /*
     * For each column j in the distance matrix D,
     *  printf("for test image %d: \n", j);
     * 
     * 1) copy the column to an array "col"
     *
     * 2) visualize the image sotred in j-th row of T (optional)
     *
     * 3) store the indices of the 5 smallest elements of "col" in an array "indicies"
     *
     * 4)  Create a new array "labels" with length 5. 
           Assign the value of "Y_{indices[i],0}" to the i-th element in "labels". 
           Count the number of "1" in "labels".
           If the count >= 3, print out "Prediction is 1."
           Otherwise, print out "Prediction is NOT 1."

        //Do not print out anything other than the above sentences. 
     */
    
    //DO NOT FORGET to release the memory you have allocated. 
}
