/*
    Homework 3, arrays
    Rename your file as your-UOB-id.c before submission.
*/

#include <stdio.h>

/*
Adding any function you would like to write here
*/

void main(){
// Check the output of the following code. 
// It prints out the ASCII code of the word "hello"
// However, notice it ends with an "0". 
    printf("homework 0 ------------------\n");
    char text[] = "hello";
    for(int i= 0; i<6; i++){
        printf("%d\n", text[i]);
    }
// Homework 1
    printf("homework 1 ------------------\n");

// Write your homework 2 here
    printf("homework 2 ------------------\n");

// Write your homework 3 here
     printf("homework 3 ------------------\n");
}