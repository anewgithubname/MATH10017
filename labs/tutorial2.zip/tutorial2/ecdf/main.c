#include <stdio.h>

int read_array(char *filename, double data[])
{
    FILE *f = fopen(filename, "rb");
    int numrow = getw(f);
    int numcol = getw(f);
    getw(f);
    printf("numrow: %d, numcol: %d\n", numrow, numcol);

    fread(data, sizeof(double), numrow * numcol, f);
    fclose(f);
    return numrow * numcol;
}

int count(int k, int len, int array[]){
    int count = 0; 
    //TODO: write your code here.
    return count; 
}

void main(){ 
    //read data from file
    double array[1024*100];
    int n = read_array("poiss.matrix", array);
    int X[n];
    //copy them into an integer array X
    printf("the length of the array is %d\n", n);
    for(int i = 0; i < n; i++){
        X[i] = (int)array[i];
    }

    printf("\n\nprinting ECDF from 0-5:\n");
    double ECDF[6];
    for(int k = 0; k <= 5; k++){
        // NEEDS MANUAL TYPE CONVERSION!
        ECDF[k] = (double) count(k, n, X) / n;
        printf("ECDF(%d) %f \n", k, ECDF[k]);
    }
    printf("\n");

    printf("What distribution do you think our data come from?\n");
}