#include <stdio.h>
#include <stdlib.h>

/*
NOTICE: You need to use the following command to test your code: 
g++ main.cpp -o main.out 
./main.out

DO NOT USE gcc. 
*/

int random_number(){
    return rand() % 10;
}

class Matrix{
    //TODO: define your private fields here

    /* takes 2D matrix index i, j 
       convert it to a linearized index. 
       for example, 1,3 is converted to 1*numcol + 3.  
     */
    int idx(int i, int j) {
        //TODO: write your code here
    }

public:
    /* Initialize the matrix with zeros.
    nrow: input, number of rows
    ncol: input, number of cols;
    */
    void zeros(int nrow, int ncol){
        //TODO: Write your code here
    }


    /* Fill the matrix with a flattened matrix, stored in an array. 
    * nrow, number of rows
    * ncol, number of columns
    * a, an array containing the flattened matrix. 
    */
    //TODO: Write your method here

    /*
    TODO: Write your print function here. 
    */

    /*
    Compute matrix multiplication C = AB, where A is the current matrix. 
    B: the other matrix
    return: C 
    */
    Matrix dot(Matrix B){
        Matrix C;  C.zeros(numrow, B.numcol);
        
        if(numcol != B.numrow){
            printf("Error: Matrix dimensions do not match.\n");
            return C;
        }

        //TODO: Write your matrix multiplication code here        

        return C; 
    }

    /*
        Free up the memory allocated by zeros, or rand. 
    */
    void free_mem(){
        //TODO: write your code here. 
    }

};

int main(){
    //elements we will put in the matrices. 
    //note the line breaking does NOT matter here. They are both 1D arrays. 
    float a[6] = {1,2,3,
                  4,5,6};
    float b[6] = {1,2,
                  3,4,  
                  5,6};

    //TODO: Create two matrices A and B using array a and b
    // A will be an 2 by 3 matrix
    // B will be an 3 by 2 matrix

    printf("printing Matrix A:\n");
    //TODO: print matrix A
    printf("\n");

    printf("printing Matrix B:\n");
    //TODO: print matrix B
    printf("\n");

    //TODO: compute C = AB
    printf("Matrix C = AT*B:\n");
    //TODO: print matrix C
    printf("\n");

    // DO NOT FORGET TO FREE UP MEMORY!!
    //TODO: free your memories here!
}