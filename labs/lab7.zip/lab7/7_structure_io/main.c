#include <stdio.h>
#include <stdlib.h>

// TODO: define your matrix structure here.
/* syntax:
struct name{
    datatype variable1;
    datatype variable2;
    datatype variable3;
};
*/


// TODO: define Matrix an alias to your matrix structure.
// hint: typedef ...

/*
Takes 2D index i, j of a matrix M, return the linearized index
e.g. I have a 2D index 1,2 of a 3 by 4 matrix M, the linearized index should be 1*4+2 = 6
*/
int idx(int i, int j, Matrix M)
{
    //TODO: write your code here
}

/*
Read a matrix from file.
filename: the file that contains the matrix.
*/
Matrix read_matrix(char *filename)
{
    FILE *f = fopen(filename, "rb");
    // read int variables to the file.
    int numrow = getw(f);
    int numcol = getw(f);
    Matrix M = {numrow, numcol, calloc(numrow * numcol, sizeof(int))};

    // TODO: read the matrix from file.

    // DO NOT FORGET!!
    fclose(f);

    // TODO: return the matrix you have just read from the file
    // return ???
}

/*
Write matrix M to file
M: the matrix to be written
filename: name of the file to be created.
*/
void write_matrix(Matrix M, char *filename)
{
    FILE *f = fopen(filename, "wb");
    // write int variables to the file.
    putw(M.numrow, f);
    putw(M.numcol, f);

    // TODO: Write elements of the matrix to the file.

    // DO NOT FORGET!!
    fclose(f);
}

/*
Computer matrix multiplication A*B, and store the result in C.
*/
void multiply(Matrix A, Matrix B, Matrix C)
{
    // TODO modify the matrix multiplication code you have written
    //  in lab 4, so that it works on matrix structures A, B and C

    // https://github.com/anewgithubname/MATH10017/blob/main/homework/sol4.c

}

// do not change
void print_matrix(Matrix A);
void fill_matrix(Matrix A);
int is_the_same(Matrix A, Matrix B);

void main()
{
    printf("------- testing matrix IO --------\n");
    Matrix A = read_matrix("A.matrix");
    write_matrix(A, "A0.matrix");
    Matrix A0 = read_matrix("A0.matrix");

    if(is_the_same(A,A0)){
        printf("Test OK!\n");
    }else{
        printf("Something is wrong with your IO code!\n");   
    }
    // DO NOT FORGET!
    free(A.elements); 
    free(A0.elements);


    printf("\n------- matrix multiplication --------\n");
    //TODO, read A and B from matrix files
    // compute C=A*B, and write C to a matrix file C.matrix 
    // using the functions you just wrote. 

}

// do not change.
void print_matrix(Matrix A)
{
    for (int i = 0; i < A.numrow; i++)
    {
        for (int j = 0; j < A.numcol; j++)
        {
            printf("%2d ", A.elements[idx(i, j, A)]);
        }
        printf("\n");
    }
}

void fill(Matrix A)
{
    for (int i = 0; i < A.numrow; i++)
    {
        for (int j = 0; j < A.numcol; j++)
        {
            A.elements[idx(i, j, A)] = i * A.numcol + j + 1;
        }
    }
}

int is_the_same(Matrix A, Matrix B)
{
    for (int i = 0; i < A.numrow; i++)
    {
        for (int j = 0; j < A.numcol; j++)
        {
            if (A.elements[idx(i, j, A)] != B.elements[idx(i, j, B)])
            {
                return 0; 
            }
        }
    }
    return 1; 
}
